# PushBots-Wordpress-Plugin
This plugin makes it easy to integrate your website with PushBots. 
