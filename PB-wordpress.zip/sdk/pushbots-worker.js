if (typeof importScripts === 'function') {
  importScripts('https://cdn.pushbots.com/js/pushbots-worker.js');
}
