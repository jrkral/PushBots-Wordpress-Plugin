=== PushBots - Web Push Notifications ===
Plugin Name: PushBots - Web Push Notifications
Plugin URI: https://www.pushbots.com/
Description: Reach out to your Wordpress visitors with desktop push notifications
Author: Abdallah Nofal
Author URI: https://github.com/AbdallahNofal/
Version: 1.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Reach out to your Wordpress visitors with desktop push notifications. Now supporting Chrome, Firefox, and Safari.

== Description ==
Increase user engagement, retention and life-time-value for your app and website via the power of push messaging. This plugin uses PushBots.com service and requires you to have a working account.  

== Installation ==

1. Install PushBots from the WordPress.org plugin directory or by uploading the PushBots plugin folder to your wp-content/plugins directory.
2. Active the PushBots plugin from your WordPress settings dashboard.
3. Follow the instructions on the Setup page.

== Changelog ==


= 1.0.0 =
- Initial release of the plugin



